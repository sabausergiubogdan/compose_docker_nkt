#!/bin/bash
#Backup BitBucket Data Directory Script
#Author = Accesa
#Version 3.0

Time=`date +%Y-%m-%d_%H-%M-%S`

WorkDir=`pwd`
DataVol=bitbucket_home
InstVol=bitbucket_install
DesDir=/applications/docker/backup/
# how many old backups should we keep
NR_BACKUP_TO_KEEP=4

LogFileName=backup-jira-${Time}.log
LogFile=${DesDir}/${LogFileName}
if [ ! -f ${LogFile} ]; then
   touch ${LogFile}
fi

echo "Backup session - START."  >> ${LogFile}
echo "" >> ${LogFile}

echo "Backup Jira data - START."  >> ${LogFile}
docker run -v ${DataVol}:/volume -v ${DesDir}:/backup --rm loomchild/volume-backup backup ${DataVol}_${Time}
docker run -v ${InstVol}:/volume -v ${DesDir}:/backup --rm loomchild/volume-backup backup ${InstVol}_${Time}
ResVal=$?
if [ $ResVal -ne 0 ]; then
   echo "Archive failed with return code ${ResVal}." >> ${LogFile}
else
   echo "Archive for ${DataVol} and ${InstVol} was successfully created."  >> ${LogFile}
fi
echo "End backup Jira data."  >> ${LogFile}
echo "" >> ${LogFile}

echo "Remove old backups" >>${LogFile} 2>&1
BACKUP_FILES=${DesDir}/*.tar.bz2
(ls -t ${BACKUP_FILES}|head -n ${NR_BACKUP_TO_KEEP};ls ${BACKUP_FILES})|sort|uniq -u|xargs -r rm -v >>${LogFile} 2>&1
# move to offload server
#if [ ! -z "${BACKUP_DIR}" ]; then
#        echo "Deleting backups older than 3 days from ${BACKUP_DIR}" >>${LogFile} 2>&1
#        find ${BACKUP_DIR} -mtime +1 -name "*jira*tar.bz2*" -exec rm {} \;
#        echo "Move new backup to ${BACKUP_DIR}" >>${LogFile} 2>&1
#        cp --no-preserve=mode,ownership ${BACKUP_FILE} ${BACKUP_DIR} 2>&1 && rm -f ${BACKUP_FILE} 2>&1
#fi

echo "Remove old backup logs" >>${LogFile} 2>&1
LOG_FILES=${DesDir}/*.log
(ls -t ${LOG_FILES} | head -n ${NR_BACKUP_TO_KEEP}; ls ${LOG_FILES}) | sort | uniq -u | xargs -r rm -v >>${LogFile} 2>&1

echo "Backup session - END."  >> ${LogFile}
echo "" >> ${LogFile}
