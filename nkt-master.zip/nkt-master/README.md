NKT

Implementation project

Tools:
Jira, Confluence, Bitbucket, Bamboo, SonarQube, Nexus, POSTGRES

Documentation:
https://accesa.atlassian.net/wiki/spaces/DC/pages/856719520/NKT
